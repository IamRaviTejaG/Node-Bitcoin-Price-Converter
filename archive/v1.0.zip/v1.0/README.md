# Bitcoin Price Converter
###### Last Updated: 13 December 2017.

## Dependencies
* Express (`npm install express`)
* Nodemon (`npm install nodemon`)
* Blockchain API (`npm install blockchain.info`)
* Morgan (`npm install morgan`)

## Installing
Clone the repo and run `npm install <foldername>` to install. This will install all the dependencies from `package.json`.

## Using
Use `node app.js` or `nodemon app.js` to run the application and visit `localhost:3000/btc/<yourPreferredCurrency>` in your browser. To change the port, use `PORT=xxxx node app.js` instead.

Replace <yourPreferredCurrency> with `usd`, `inr`, `eur`, `aud`, `cad`, etc.

***
##### Copyright © 2017 Ravi Teja Gannavarapu
